# hysteria-install

hysteria2

```
wget -N --no-check-certificate https://raw.githubusercontent.com/Ptechgithub/hysteria-install/main/hy2/hysteria2.sh && bash hysteria2.sh
```


.
- [singbox](https://github.com/SagerNet/sing-box/releases/tag/v1.4.1) hysteria2 config:

After installation, update it to the latest version.  (Version 1.5.0)and above

```
https://raw.githubusercontent.com/Ptechgithub/hysteria-install/main/hy2/sing-hy2.json
```

.
  
hysteria1

```
wget -N --no-check-certificate https://raw.githubusercontent.com/Ptechgithub/hysteria-install/main/hysteria.sh && bash hysteria.sh
```
![1](https://raw.githubusercontent.com/Ptechgithub/hysteria-install/main/media/1.jpg)
